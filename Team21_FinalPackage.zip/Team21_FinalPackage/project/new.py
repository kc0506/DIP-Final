import numpy as np

x = np.array([1, 2, 3])
print(np.argsort(x))
# print(np.exp(-115195))
